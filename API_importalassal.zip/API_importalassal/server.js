const express = require('express');
const app = express();
const port = 4000;

const cors = require('cors');
app.use(cors());

const orszagok = {
    magyarorszag : {
        nev : "Magyarország",
        fovaros : "Budapest",
        lakossag : "9.6M"
    },

    nemetorszag : {
        nev : "Németország",
        fovaros : "Berlin",
        lakossag : "83M"
    },

    franciaorszag : {
        nev : "Franciaország",
        fovaros : "Párizs",
        lakossag : "67.4M"
    },

    olaszorszag : {
        nev : "Olaszország",
        fovaros : "Róma",
        lakossag : "59M"
    },

    spanyolorszag : {
        nev : "Spanyolország",
        fovaros : "Madrid",
        lakossag : "47M"
    }
};

app.get('/api/:orszag', (req, res) => {
    const orszag = req.params.orszag.toLowerCase();
    if(orszagok[orszag]){
        res.json(orszagok[orszag]);
    } else{
        res.status(404).json({error : "Nincs ilyen ország!"})
    }
});

app.get('/api/:orszag/:adat', (req, res) => {
    const orszag = req.params.orszag.toLowerCase();
    const adat = req.params.adat.toLowerCase();
    if(orszagok[orszag]){
        if(orszagok[orszag][adat]){
            res.json({[adat] : orszagok[orszag][adat]});
        }
        else{
            res.status(404).json({error : "Nincs ilyen adat!"})    
        }
    } else{
        res.status(404).json({error : "Nincs ilyen ország!"})
    }
});

app.get('/fovarosok', (req, res) => {
    let lista = []
    for(let i in orszagok){
        lista.push(orszagok[i].fovaros)
    }
    res.json(lista)
});

app.get('/orszagoklekeres', (req, res) => {
    res.json(orszagok);
});

app.use(express.static('public'));

app.listen(port, () => {
    console.log("Szerver fut a 4000-es porton!")
});